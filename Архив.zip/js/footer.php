<footer>
            <div class="container-fluid footer">    
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 left">
                    <h4>КОЛЛЕКЦИИ</h4><br>
                    <p>Женщинам</p>
                    <p>Мужчинам</p>
                    <p>Детям</p>
                    <p>Новинки</p>
                   </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 middle">
                    <h4>МАГАЗИН</h4><br>
                    <p> О нас</p>
                    <p> Доставка</p>
                    <p>Работай с нами</p>
                    <p>Контакты</p>
                   </div>
                   <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 right">
                <h4>МЫ В СОЦИАЛЬНЫХ СЕТЯХ</h4><br>
                 <p>Сайт разработан в inordic.ru</p>
                 <p>2018 Все права защищены</p>
                 <div class="social-buttom"></div>
                    <a href="#"><i class="fa fa-twitter-square fa-4x" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-vk fa-4x" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-instagram fa-4x" aria-hidden="true"></i></a>
                </div>
               </div>
               </div>
            </div>
        </footer>
        
        <?php
        include_once "elements_page/form.php";
        ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/cart/cart.js"></script> 
    <script src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/script.js"></script> 
    
    </body>
</html>
