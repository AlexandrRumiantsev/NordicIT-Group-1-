<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<?php
 include_once "../header.php"; 
 ?>
 