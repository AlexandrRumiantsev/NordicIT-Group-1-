<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/header.php");?>

<p id="h1men">МУЖЧИНАМ</p>
<p id="h2men">Джинсы</p>
<main>
<div class="men-goods">    
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jn1/jn1.php">
                                <div class="image-box">
                                    <img class="image-box__item"  src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/11.jpg" alt="">
                                </div>
                                <p id="men-text">Джинсы синие<br>4800 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            <a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jn2/jn2.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/12.jpg" alt="">
                                </div>
                                <p id="men-text">Джинсы голубые<br>4200 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
</div>
</main>

<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/footer.php");?>
