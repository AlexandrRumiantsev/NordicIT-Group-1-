<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/header.php");?>
<div class="men-goods">    
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="goods-out"></div>
</div>
</div>
<<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/footer.php");?>
<script type="text/javascript" src="script.js"></script>