<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/header.php");?>

<p id="h1men">МУЖЧИНАМ</p>
<p id="h2men">Куртки</p>
<main>
<div class="men-goods">    
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk1/jk1.php">
                                <div class="image-box">
                                    <img class="image-box__item"  src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/1.jpg" alt="">
                                </div>
                                <p id="men-text">Куртка синяя<br>6100 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk2/jk2.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/2.jpg" alt="">
                                </div>
                                <p id="men-text">Куртка с капюшоном<br>6300 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk3/jk3.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/3.png" alt="">
                                </div>
                                <p id="men-text">Куртка с карманами<br>3100 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk6/jk6.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/6.jpg" alt="">
                                </div>
                                <p id="men-text">Стильная кожанная куртка<br>12000 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk5/jk5.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/4.jpg" alt="">
                                </div>
                                <p id="men-text">Кожанная куртка<br>8800 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="jk4/jk4.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/5.jpg" alt="">
                                </div>
                                <p id="men-text">Куртка casual<br>7100 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
</div>
</main>
<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/footer.php");?>