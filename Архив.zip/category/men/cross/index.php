<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/header.php");?>

<p id="h1men">МУЖЧИНАМ</p>
<p id="h2men">Кроссовки</p>
<main>
<div class="men-goods">    
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="k1/k1.php">
                                <div class="image-box">
                                    <img class="image-box__item"  src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/7.jpg" alt="">
                                </div>
                                <p id="men-text">Кеды серые<br>2900 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="k2/k2.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/8.jpg" alt="">
                                </div>
                                <p id="men-text">Кеды черные<br>4500 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="k3/k3.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/9.jpg" alt="">
                                </div>
                                <p id="men-text">Кеды с полоской<br>5900 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                            </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                            <a href="k4/k4.php">
                                <div class="image-box">
                                    <img class="image-box__item" src="http://<?=$_SERVER["SERVER_NAME"]?>:<?=$_SERVER['SERVER_PORT']?>/img/catalog/10.jpg" alt="">
                                </div>
                                <p id="men-text">Кеды allseasson<br>9200 руб.<i class="fa fa-shopping-cart" aria-hidden="true"></i></p>
                                </a>
                            </div>
</div>
</main>
<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/footer.php");?>