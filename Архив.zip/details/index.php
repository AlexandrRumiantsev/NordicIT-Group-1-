<?php 
include_once('../header.php'); 
include_once(__DIR__.'/model/goods.php'); 
?>

<style>
  html body .footer-info {
    margin-top: 0px;
  }
</style>   

<?php 
include_once('../footer.php'); 
?> 