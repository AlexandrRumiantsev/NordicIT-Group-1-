<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/header.php");?>    
        <main>
            <div class="title">
                <p id="p1">НОВЫЕ ПОСТУПЛЕНИЯ ВЕСНЫ</p>
                    <p id="p2">Мы подготовили для вас лучшие новинки сезона</p>
             <button type="button" id="news">ПОСМОТРЕТЬ НОВИНКИ</button>
                </div>
                <div class="grid">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><p>ДЖИНСОВЫЕ <br> КУРТКИ</p>
                           <I>NEW ARRIVAL</I></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><img src="img/icons/att.png" class="logo-box"><br>
                   <i>Каждый сезон мы подготавливаем для Вас исключительно лучшую модную одежду.Следите за нашими новинками</i></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">←<br><p> ЭЛЕГАНТНАЯ <br> ОБУВЬ</p><i>БОТИНКИ , КРОСОВКИ</i></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><p>ДЖИНСЫ <br><I>от 3200 руб.</I></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><img src="img/icons/att.png" class="logo-box"><br><i>Самые низкие цены в <br> Мокве.<br>Нашли дешевле?Вернем разницу</i></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><p>ДЕТСКАЯ <br> ОДЕЖДА</p><i>NEW ARRIVAL</i></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">←<br><p>АКСЕССУАРЫ</p></div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><p>CПОРТИВНАЯ <br> ОДЕЖДА</p><i>от 590 руб.</i></div>
                </div>
        </main>

        <div class="section">
            <div class="container-fluid">    
                <div class="row centred">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <p id="p3">БУДЬ ВСЕГДА ВКУРСЕ ВЫГОДНЫХ ПРЕДЛОЖЕНИЙ</p>
                         <p id="p4">Подписывайся и следи за новинками и выгодными предложения</p> 
                    </div>
                </div>
            </div>  
            <div class="container-fluid">    
                <div class="row centred">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>  
                    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">     
                        <div class="input-box">
                            <input type="email"  name="email" placeholder="Email">
                            <span class="button"> записаться </span>
                        </div>
                    </div>
                </div>
            </div>
<?php require_once ($_SERVER["DOCUMENT_ROOT"]."/footer.php");?>